    <footer>
	<p>&copy; <?php echo date('Y'); ?>. All rights reserved. <br>
	<span style="position:fixed;bottom:-200px;">Powered by <a href="https://whitelabelpress.org" target="_blank">WLP</a></span></p>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>

